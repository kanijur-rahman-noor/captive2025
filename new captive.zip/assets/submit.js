
function form() {

 const phone = document.getElementById("numb").value.trim();
  if (phone !== "") {
    setCookie('user_phone', phone);
  }
    var location = svlc; 
    var lat = svlat;
    var lon = svlon;
    var did = DID;
    var vid = VID;
    var aid = aid;
    var hg = HOSTGROUP;
    var uid = UID;
    var mac = ZT_MAC;
    var HOST_NAME = HOSTNAME;
    const visitorId = getCookie('visitorId');
    var data = {
        phone: phone,
        location: location,
        lat: lat,
        lon: lon,
        did: did,
        vid: vid,
        aid: aid,
        hg: hg,
        uid: uid,
        mac: mac,
        visitorId: visitorId,
        hostname: HOST_NAME
    };


const queryString = new URLSearchParams(data).toString();
var url = `http://13.232.84.170/reports/connection_data_api?${queryString}`
console.log(url);

 fetch(url, { method: 'GET' })
                .then(response => response.text())
                .then(result => console.log(result))
                .catch(error => console.log('error', error));
}

